package hms;


import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Hp
 */
public interface dto_interface {
    void insertintopatient(patient obj) throws SQLException ;
    int insertintodoctor(doctor obj) throws SQLException ;
    void deletedoctor(String name) throws SQLException;
    void sarchdoctor(String name)throws SQLException;
     void addappointment(appointment obj)throws SQLException;
    void addbill(bill obj)throws SQLException;
    //void addappointment(appointment obj)throws SQLException;
}
