/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hms;
import frames.dashboard;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hp
 */
public class Hms {

    /**
     * @param args the command line arguments
     */
    public static Connection getconnection(){
     String url="jdbc:mysql://127.0.0.1:3306/hms";
        String username="root";
        String password="";
        Connection conn=null;
        if(conn==null){
        try {
             conn=DriverManager.getConnection(url,username,password);
             
        } catch (SQLException ex) {
            Logger.getLogger(Hms.class.getName()).log(Level.SEVERE, null, ex);
        }}
        return conn;
    }
    public static void main(String[] args) {
        // TODO code application logic here
       dto_implement dt=new dto_implement();
       /*doctor d=new doctor("ahmad",25,"male",22000,"mbbs");
       int id=dt.insertintodoctor(d);
       doctor dd=new doctor("ahmad1",25,"male",22000,"mbbs");
        id=dt.insertintodoctor(dd);
       doctor ddd=new doctor("ahmad2",25,"male",22000,"mbbs");
       id=dt.insertintodoctor(ddd);
       patient p=new patient(id,"ali",22,"male","fever");
       dt.deletedoctor("ahmad1");
        dt.insertintopatient(p);*/
        //dt.sarchdoctor("ahmad");
       /* appointment app=new appointment(LocalDate.of(2024,11,10),LocalTime.of(12,24),1,1,"fever");
        dt.addappointment(app);
        
        bill bil=new bill(LocalDate.of(2024,11,10),22000,"amna",1);
    dt.addbill(bil);*/
       
       new dashboard().setVisible(true);
    }
    
}
