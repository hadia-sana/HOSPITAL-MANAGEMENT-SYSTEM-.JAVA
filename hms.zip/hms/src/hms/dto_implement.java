package hms;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Hp
 */
public class dto_implement implements dto_interface {
    public  void insertintopatient(patient obj){
    Connection conn= Hms.getconnection();
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
            CallableStatement st=conn.prepareCall("{Call addintopatient2(?,?,?,?,?)}");
            st.setInt(1,obj.getDocid());
            st.setString(2, obj.getName());
            st.setInt(3,obj.getAge());
            st.setString(4, obj.getGender());
            st.setString(5, obj.getDiagnose());
            
            st.executeUpdate();
             JOptionPane.showMessageDialog(null,"added");
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
         JOptionPane.showMessageDialog(null,"not found");}
    }
    public  int insertintodoctor(doctor obj){
    Connection conn= Hms.getconnection();
    CallableStatement st=null;
    int id=-1;
        try {
            //in newname varchar (30),in age int,in gender varchar (15),in diagnose varchar (16),in id int)
             st=conn.prepareCall("{Call adddoctor3(?,?,?,?,?,?)}");
            st.setString(1, obj.getName());
            st.setInt(2,obj.getAge());
            st.setString(3, obj.getGender());
            st.setInt(4, obj.getSalary());
            st.setString(5,obj.getQualification());
            st.registerOutParameter(6,java.sql.Types.OTHER);
            st.executeUpdate();
            id=st.getInt(6);
            JOptionPane.showMessageDialog(null,"added");
          
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
        
            return id;
        
    }
    public void deletedoctor(String name){
        Connection conn=Hms.getconnection();
        
    PreparedStatement st=null;
        try {
            st = conn.prepareStatement("delete from doctor where name = ? ");
        st.setString(1,name);
    st.executeUpdate();
    JOptionPane.showMessageDialog(null,"deleted");
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    }
    public void deletepatient(String name){
        Connection conn=Hms.getconnection();
        
    PreparedStatement st;
        try {
            st = conn.prepareStatement("delete from patient2 where name = ? ");
        st.setString(1,name);
    st.executeUpdate();
    JOptionPane.showMessageDialog(null,"deleted");
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    
    
    }
   
    /*public void sarchpatient(String name){
     Connection conn=Hms.getconnection();
     PreparedStatement st=null;
        try {
            st = conn.prepareStatement("select * from patient2 where name = ? ");
        st.setString(1,name);
        try{
        ResultSet rs=st.executeQuery();
        DefaultTableModel model=(DefaultTableModel) jTable1.getmodel();
        while(rs.next()){
        
        }
        
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null,"not found");
        }
    
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    }*/
    public void sarchdoctor(String name){
     Connection conn=Hms.getconnection();
     PreparedStatement st=null;
        try {
            st = conn.prepareStatement("select * from doctor where name = ? ");
        st.setString(1,name);
        try{
        ResultSet rs=st.executeQuery();}
        catch(Exception e){
        JOptionPane.showMessageDialog(null,"not found");
        }
    
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");}
    }
    public void addappointment(appointment obj){
    Connection conn=Hms.getconnection();
        try {
            CallableStatement st=conn.prepareCall("{call addappoint(?,?,?,?,?)}");
            //(newdatt,newtim,newdocid,newpid,apptype2);

            st.setDate(1,java.sql.Date.valueOf(obj.getDate()));
             st.setTime(2,java.sql.Time.valueOf (obj.getTime()));
             st.setInt(3,obj.getDocid());
             st.setInt(4,obj.getPid());
             st.setString(5,obj.getType());
             st.executeUpdate();
             JOptionPane.showMessageDialog(null,"added");
        
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");
        }
    
    
    
    }
    public void datewisebill(LocalDate date){
    
    
    }
    public void addbill(bill obj){Connection conn=Hms.getconnection();
        try {
            CallableStatement st=conn.prepareCall("{call addbill(?,?,?,?)}");
            //(newdatt,newtim,newdocid,newpid,apptype2);

            st.setDate(1,java.sql.Date.valueOf(obj.getDate()));
          
             st.setInt(2,obj.getPayamount());
             
             st.setString(3,obj.getName());
             st.setInt(4,obj.getAppid());
             st.executeUpdate();
             JOptionPane.showMessageDialog(null,"added");
        
        } catch (SQLException ex) {
            //Logger.getLogger(dto_implement.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null,"not found");
        }
    
    }
}
