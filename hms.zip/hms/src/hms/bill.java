/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

import java.time.LocalDate;

/**
 *
 * @author Hp
 */
public class bill {

    // Stores billing information, including date,
    //payable amount, payer name, and appointment ID.
    LocalDate date;
 int payamount;
 String name;
 int appid;
    public bill(LocalDate date, int payamount, String name, int appid) {
        this.date = date;
        this.payamount = payamount;
        this.name = name;
        this.appid = appid;
    }

    public LocalDate getDate() {
        return date;
    }

    public int getPayamount() {
        return payamount;
    }

    public String getName() {
        return name;
    }

    public int getAppid() {
        return appid;
    }
 


} 

