/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hms;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Hp
 */
public class appointment {
    LocalDate date;
    LocalTime time;
    int appid;

    public LocalDate getDate() {
        return date;
    }

    public LocalTime getTime() {
        return time;
    }

    public int getAppid() {
        return appid;
    }

    public int getDocid() {
        return docid;
    }

    public int getPid() {
        return pid;
    }

    public String getType() {
        return type;
    }

    public appointment(LocalDate date, LocalTime time, int appid, int docid, int pid, String type) {
        this.date = date;
        this.time = time;
        this.appid = appid;
        this.docid = docid;
        this.pid = pid;
        this.type = type;
    }
     public appointment(LocalDate date, LocalTime time,  int docid, int pid, String type) {
        this.date = date;
        this.time = time;
        
        this.docid = docid;
        this.pid = pid;
        this.type = type;
    }

    public void setAppid(int appid) {
        this.appid = appid;
    }
    int docid;
    int pid;
    String type;
    
}
