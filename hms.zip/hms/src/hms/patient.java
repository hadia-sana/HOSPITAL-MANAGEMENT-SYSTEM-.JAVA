package hms;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Hp
 */
public class patient {
    private int id;
    private String name;
    private int age;
    private String gender;
    private String diagnose;
   private int docid;

    public patient( int docid,String name, int age, String gender, String diagnose) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.diagnose = diagnose;
        this.docid = docid;
    }
   /* public patient(int id, String name, int age, String gender, String diagnose) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.diagnose = diagnose;
    }*/

    public int getDocid() {
        return docid;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getDiagnose() {
        return diagnose;
    }

    
    
}
